package com.example.gestordetareas

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.gestordetareas.ui.theme.GestordeTareasTheme
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Task(
    val id: String,
    val description: String,
    val hour: Int,
    val minute: Int,
    var photoPath: String? = null,
    var completed: Boolean = false
)

class TaskListActivity : ComponentActivity() {
    private lateinit var takePictureLauncher: ActivityResultLauncher<Uri>
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>
    private var pendingTaskIndex: Int? = null
    private var currentPhotoUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Register permission launcher
        requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                launchCameraForPendingTask()
            } else {
                Toast.makeText(this, "Se necesita permiso de cámara", Toast.LENGTH_SHORT).show()
                // Optionally send user to app settings
            }
        }

        // Register take picture launcher
        takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success && currentPhotoUri != null && pendingTaskIndex != null) {
                val uri = currentPhotoUri
                // update task with photo and mark completed
                val tasks = loadTasks(this).toMutableList()
                val idx = pendingTaskIndex!!
                val task = tasks[idx]
                task.photoPath = uri.toString()
                task.completed = true
                saveTasks(this, tasks)
                // refresh UI by re-setting content
                setContentComposable()
            } else {
                Toast.makeText(this, "No se tomó la foto", Toast.LENGTH_SHORT).show()
            }
            pendingTaskIndex = null
            currentPhotoUri = null
        }

        setContentComposable()
    }

    private fun setContentComposable() {
        setContent {
            GestordeTareasTheme {
                TaskListScreen(
                    loadTasks(this),
                    onAdd = {
                        startActivityForResult(Intent(this, AddTaskActivity::class.java), 1001)
                    },
                    onComplete = { index ->
                        // ask for camera permission first
                        pendingTaskIndex = index
                        if (checkSelfPermission(Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            launchCameraForPendingTask()
                        } else {
                            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                    }
                )
            }
        }
    }

    private fun launchCameraForPendingTask() {
        val idx = pendingTaskIndex ?: return
        try {
            val imageFile = createImageFile()
            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", imageFile)
            currentPhotoUri = uri
            takePictureLauncher.launch(uri)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error creando archivo de imagen", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir = getExternalFilesDir("images")
        if (!storageDir!!.exists()) storageDir.mkdirs()
        return File(storageDir, "IMG_${timeStamp}.jpg")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            // received new task
            val description = data?.getStringExtra("description") ?: return
            val hour = data.getIntExtra("hour", 0)
            val minute = data.getIntExtra("minute", 0)
            val tasks = loadTasks(this).toMutableList()
            tasks.add(Task(UUID.randomUUID().toString(), description, hour, minute))
            saveTasks(this, tasks)
            setContentComposable()
        }
    }

    companion object {
        fun loadTasks(context: Context): List<Task> {
            val prefs = context.getSharedPreferences("tasks", Context.MODE_PRIVATE)
            val json = prefs.getString("tasks_json", "[]") ?: "[]"
            val arr = JSONArray(json)
            val list = mutableListOf<Task>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Task(
                        id = o.getString("id"),
                        description = o.getString("description"),
                        hour = o.getInt("hour"),
                        minute = o.getInt("minute"),
                        photoPath = if (o.has("photoPath")) o.optString("photoPath", null) else null,
                        completed = o.optBoolean("completed", false)
                    )
                )
            }
            return list
        }

        fun saveTasks(context: Context, tasks: List<Task>) {
            val arr = JSONArray()
            tasks.forEach { t ->
                val o = JSONObject()
                o.put("id", t.id)
                o.put("description", t.description)
                o.put("hour", t.hour)
                o.put("minute", t.minute)
                if (t.photoPath != null) o.put("photoPath", t.photoPath)
                o.put("completed", t.completed)
                arr.put(o)
            }
            val prefs = context.getSharedPreferences("tasks", Context.MODE_PRIVATE)
            prefs.edit().putString("tasks_json", arr.toString()).apply()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskListScreen(tasks: List<Task>, onAdd: () -> Unit, onComplete: (Int) -> Unit) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Text("+") }
        }
    ) { innerPadding ->
        LazyColumn(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
            itemsIndexed(tasks) { index, task ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = task.description)
                        Text(text = String.format("%02d:%02d", task.hour, task.minute))
                        if (task.completed) {
                            Text(text = "Completada")
                        } else {
                            Button(onClick = { onComplete(index) }) { Text("Marcar completada (foto)") }
                        }
                    }
                }
            }
        }
    }
}
