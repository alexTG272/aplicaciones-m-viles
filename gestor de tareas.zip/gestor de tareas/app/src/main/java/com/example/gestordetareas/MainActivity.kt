package com.example.gestordetareas

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.gestordetareas.ui.theme.GestordeTareasTheme

/**
 * Simple Login screen implemented with Jetpack Compose.
 * - Register opens RegisterActivity
 * - Login checks SharedPreferences and opens TaskListActivity on success
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GestordeTareasTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    LoginScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(modifier: Modifier = Modifier) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(modifier = modifier.padding(16.dp)) {
        Text(text = "Gestor de Tareas - Login")
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") })
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") })
        Button(onClick = {
            val prefs = context.getSharedPreferences("users", MODE_PRIVATE)
            val savedPass = prefs.getString(email, null)
            if (savedPass != null && savedPass == password) {
                context.startActivity(Intent(context, TaskListActivity::class.java))
            } else {
                Toast.makeText(context, "Credenciales inválidas", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text("Ingresar")
        }
        TextButton(onClick = { context.startActivity(Intent(context, RegisterActivity::class.java)) }) {
            Text("Registrarse")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun LoginPreview() {
    GestordeTareasTheme {
        LoginScreen()
    }
}