package com.example.gestordetareas

import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.gestordetareas.ui.theme.GestordeTareasTheme
import java.util.*

class AddTaskActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GestordeTareasTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AddTaskScreen(modifier = Modifier.padding(innerPadding)) { description, hour, minute ->
                        val intent = Intent().apply {
                            putExtra("description", description)
                            putExtra("hour", hour)
                            putExtra("minute", minute)
                        }
                        setResult(RESULT_OK, intent)
                        finish()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskScreen(modifier: Modifier = Modifier, onSave: (String, Int, Int) -> Unit) {
    var description by remember { mutableStateOf("") }
    var hour by remember { mutableStateOf(12) }
    var minute by remember { mutableStateOf(0) }
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(modifier = modifier.padding(16.dp)) {
        Text(text = "Agregar tarea")
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Descripción") })
        Button(onClick = {
            val cal = Calendar.getInstance()
            TimePickerDialog(context, { _, h, m ->
                hour = h
                minute = m
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }) { Text(text = "Seleccionar hora: ${String.format("%02d:%02d", hour, minute)}") }
        Button(onClick = { if (description.isNotBlank()) onSave(description, hour, minute) }) {
            Text("Guardar")
        }
    }
}
